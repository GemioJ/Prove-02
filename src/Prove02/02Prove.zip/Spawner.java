package Prove02;

public interface Spawner {

    public Creature spawnNewCreature();
}
